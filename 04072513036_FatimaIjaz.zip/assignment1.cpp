#include <iostream>
#include <forward_list>
#include <vector>
#include <list>
#include <chrono>
#include <cstdlib>
#include <string>
#include <algorithm>

const int n = 10000;
// returns current time
auto now() {
	return std::chrono::steady_clock::now();
}
// shows the time elapsed
void show(std :: string name, auto start ) {
	std::chrono::duration<double, std::milli> t = now() - start; 
	std::cout << name << ": " << t.count() << "ms" << std::endl;
}
void heapify(std::vector<int>& a, int size, int parent) {
    int biggest = parent;
    int left = 2 * parent + 1;
    int right = 2 * parent + 2;

    if (left < size && a[left] > a[biggest]) 
        biggest = left;
    if (right < size && a[right] > a[biggest])
        biggest = right;

    if (biggest != parent) {
        std::swap(a[parent], a[biggest]);
        heapify(a, size, biggest);
    }
}
void heapSort(std::vector<int>& a) {
    int size = a.size();
    for (int i = (size / 2) - 1; i >= 0;--i) 
        heapify(a, size, i);  
    for (int i = size - 1; i > 0; --i) {                           
        std::swap(a[0], a[i]);
        heapify(a, i, 0);
    }
}
void insertionSort(std::vector<int>& a) {
    int size = a.size();
    for (int i = 1; i < size; ++i) {
        int val = a[i];
        int j = i - 1;
        while (j >= 0 && a[j] > val) {
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = val;
    }
}

int main() {
    std::srand(12345);
    std::vector<int> randomC, randomG;
    for (int i = 0; i < n; i++)
        randomC.push_back(std::rand() % n + 1);
    for (int i = 0; i < n; i++)
        randomG.push_back(std::rand() % n + 1);

    auto start = now();

    ///*
    std::cout << "Vector" << std::endl;
    std::vector<int> A, B, C, E, F, G;

    std::cout << "Assigning values to A,B,C" << std::endl;
    start = now();
    for (int i = 1; i <= n; ++i)
        A.push_back(i);
    show("A", start);

    start = now();
    for (int i = n; i >= 1; --i)
        B.push_back(i);
    show("B", start);

    start = now();
    for (int value : randomC)
        C.push_back(value);
    show("C", start);
     
    std::cout << "Sorting A,B,C" << std::endl;
    start = now();
    std::sort(A.begin(), A.end());
    show("A", start);

    start = now();
    std::sort(B.begin(), B.end());
    show("B", start);

    start = now();
    std::sort(C.begin(), C.end());
    show("C", start);

    std::cout << "Assigning values to D,E,F" << std::endl;
    start = now();
    for (int i = 1; i <= n; ++i)
        E.push_back(i);
    show("E", start);

    start = now();
    for (int i = n; i >= 1; --i)
        F.push_back(i);
    show("F", start);

    start = now();
    for (int value : randomG)
        G.push_back(value);
    show("G", start);

    std::cout << "Delete odds from D,E,F" << std::endl;
    start = now();
    std::erase_if(E, [](int x) { return x % 2 == 1; });
    show("E", start);

    start = now();
    std::erase_if(F, [](int x) { return x % 2 == 1; });
    show("F", start);

    start = now();
    std::erase_if(G, [](int x) { return x % 2 == 1; });
    show("G", start);
    //*/

    /*
    std::cout << "List-containers" << std::endl;
    std::list<int> A, B, C, E, F, G;

    std :: cout << "Assigning values to A,B,C" << std::endl;
    start = now();
    for (int i = 1; i <= n; ++i) 
        A.push_back(i);
    show("A", start);

    start = now();
    for (int i = n; i >= 1; --i) 
        B.push_back(i);
    show("B", start);

    start = now();
    for (int i = 0; i < n; ++i) 
        C.push_back(randomC[i]);
    show("C", start);

    std::cout << "Sorting of A,B,C " << std::endl;
    start = now();
    A.sort();
    show("A", start);

    start = now();
    B.sort();
    show("B", start);

    start = now();
    C.sort();
    show("C", start);

    std :: cout << "Assigning values to E,F,G" << std::endl;
    start = now();
    for (int i = 1; i <= n; ++i) 
        E.push_back(i);
    show("E", start);

    start = now();
    for (int i = n; i >= 1; --i) 
        F.push_back(i);
    show("F", start);

    start = now();
    for (int i = 0; i < n; ++i) 
        G.push_back(randomG[i]);
    show("G", start);

    std::cout << "Deleting odds from D,E,F" << std::endl;
    start = now();
    std::erase_if(E, [](int x) { return x % 2 == 1; });
    show("E", start);

    start = now();
    std::erase_if(F, [](int x) { return x % 2 == 1; });
    show("F", start);

    start = now();
    std::erase_if(G, [](int x) { return x % 2 == 1; });
    show("G", start);
 //*/

  /*
     std::cout << " Forwrd list" << std::endl;
     std::forward_list<int> A, B, C, E, F, G;
     std::forward_list<int>::iterator last;

     std :: cout << "Assigning values to A,B,C" << std::endl;
     start = now();
     last = A.before_begin();
     for (int i = 1; i <= n; ++i)
       last = A.insert_after(last, i);
     show("A", start);

     start = now();
     last = B.before_begin();
     for (int i = n; i >= 1; --i) 
        last = B.insert_after(last, i);
     show("B", start);

     start = now();
     last = C.before_begin();
     for (int i = 0; i < n; ++i)
        last = C.insert_after(last, randomC[i]);
     show("C", start);

     std::cout << "Sorting of A,B,C" << std::endl;
     start = now();
     A.sort();
     show("A", start);

     start = now();
     B.sort();
     show("B", start);

     start = now();
     C.sort();
     show("C", start);

     std :: cout << "Assigning values to E,F,G" << std::endl;
     start = now();
     last = E.before_begin();
     for (int i = 1; i <= n; ++i)
        last = E.insert_after(last, i);
     show("E", start);

     start = now();
     last = F.before_begin();
     for (int i = n; i >= 1; --i)
        last = F.insert_after(last, i);
     show("F", start);

     start = now();
     last = G.before_begin();
     for (int i = 0; i < n; ++i)
        last = G.insert_after(last, randomG[i]);
     show("G", start);

     std::cout << "Deleting odds of D,E,F" << std::endl;
     start = now();
     std::erase_if(E, [](int x) { return x % 2 == 1; });
     show("E", start);

     start = now();
     std::erase_if(F, [](int x) { return x % 2 == 1; });
     show("F", start);

     start = now();
     std::erase_if(G, [](int x) { return x % 2 == 1; });
     show("G", start);
  //*/

  /* std::cout << "Vectors (Part 2)" << std::endl;
     std::vector<int> A, B, C, E, F, G;

     for (int i = 1; i <= n; ++i)
      A.push_back(i);
    for (int i = n; i >= 1; --i)
      B.push_back(i);

    C = randomC;
    E = A;
    F = B;
    G = randomG;

    std::cout << "Heapsort A,B,C" << std::endl;
    start = now();
    heapSort(A);
    show("A", start);

    start = now();
    heapSort(B);
    show("B", start);

    start = now();
   heapSort(C);
   show("C", start);

   std::cout << "Insertion sort E,F,G" << std::endl;
    start = now();
   insertionSort(E);
   show("E", start);

   start = now();
  insertionSort(F);
   show("F", start);

   start = now();
   insertionSort(G);
   show("G", start);
  */
  return 0;
}